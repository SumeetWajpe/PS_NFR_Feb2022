export var Add = (x, y) => x + y;

export class Point {
  constructor(x = 10, y = 10) {
    this.x = x;
    this.y = y;
    this.z = 100;
  }
}

const PI = 3.14;
