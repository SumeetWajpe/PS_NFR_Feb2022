import { Add, Point } from "./MathModule";
import "./styles/styles.scss";

console.log(`Addition is : ${Add(20, 60)}`);
var point = new Point(100, 200);
console.log(`The point is [x:${point.x},y:${point.y}]`);
